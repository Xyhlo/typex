# Save Points

Save points are checkpoints that capture the state of the TypeX design system at each milestone. They allow you to iterate later without losing progress.

## How to Use

Each save point is a JSON file that documents what was built at that stage. They serve as:

1. **Progress markers** — see what's been completed
2. **Reference docs** — look up extracted brand values, file lists, etc.
3. **Iteration starting points** — load a save point to understand what exists before making changes

## Save Points

### 01 — Brand Extracted
**File:** `01-brand-extracted.json`

Contains the complete brand profile extracted from the TypeX codebase:
- All color values for both themes (Obsidian Ink + Ivory Paper)
- Typography scale (fonts, sizes, weights, line heights)
- Spacing scale (4px grid)
- Border radius tokens
- Shadow/elevation system
- Animation/motion tokens
- Identified gaps and user responses

### 02 — Design System Built
**File:** `02-design-system-built.json`

Documents the design system files created:
- Foundation CSS files (colors, spacing, radii, shadows, animations)
- Component CSS files (buttons, cards, inputs, navigation)
- Brand assets (logo, variations, loading animations)
- Design system overview page (index.html)

### 03 — Marketing Page Complete
**File:** `03-marketing-page-complete.json`

Documents the marketing landing page:
- All sections (Hero, Features, Preview, Testimonials, Pricing, FAQ, CTA, Footer)
- Features (theme toggle, scroll animations, responsive, reduced-motion)
- File list

## Iterating

To iterate on the design system:

1. Read the relevant save point to understand current state
2. Make your changes to the design system files
3. Update the save point JSON with what changed
4. Optionally create a new save point for major iterations

Example iteration:
```json
// After changing the accent color:
{
  "save_point": "01-brand-extracted",
  "timestamp": "2026-04-18T20:21:00Z",
  "brand": { ... },
  "iterations": [
    {
      "date": "2026-04-19",
      "change": "Updated accent from #8b7cff to #9b8cff for better contrast",
      "reason": "Accessibility audit showed WCAG AA failure on light theme"
    }
  ]
}
```
