# TypeX Design System

> The complete design system for TypeX — a beautifully crafted Markdown editor.

Built by extracting design tokens directly from the TypeX codebase, this system captures the brand identity of **Obsidian Ink** (dark) and **Ivory Paper** (light) themes.

## Quick Start

1. Open `index.html` to browse the design system
2. Open `../marketing/index.html` to see the marketing landing page
3. Open `brand/loading-animations.html` to view 20 branded loaders

## Structure

```
design-system/
├── README.md                    # This file
├── index.html                   # Design system overview with theme toggle
├── foundations/
│   ├── colors_and_type.css      # Color palette + typography tokens
│   ├── spacing.css              # 4px grid spacing scale
│   ├── radii.css                # Border radius tokens
│   ├── shadows.css              # Elevation/shadow tokens
│   └── animations.css           # Motion tokens
├── components/
│   ├── buttons.css              # Button variants (primary, secondary, ghost, danger)
│   ├── cards.css                # Standard and feature cards
│   ├── inputs.css               # Form inputs, select, toggle
│   └── navigation.css           # Top nav and sidebar nav
├── brand/
│   ├── logo.svg                 # Primary SVG logo
│   ├── logo-variations.svg      # Icon, icon+wordmark, wordmark
│   └── loading-animations.html  # 20 branded loading animations
└── assets/                      # Additional assets
```

## Design Philosophy

- **Warm neutrals** — paper-adjacent, not clinical or cold
- **Layered surfaces** — considered contrast, not flat blobs
- **Confident indigo** — the same accent hue across both themes
- **Typography first** — the writing, not the chrome, is the subject

## Themes

| Token | Obsidian Ink (Dark) | Ivory Paper (Light) |
|-------|---------------------|---------------------|
| Accent | `#8b7cff` | `#5b4de0` |
| Text | `#ebe7dd` | `#1c1b22` |
| Background | `#141318` | `#f5f2eb` |
| Content | `#17161c` | `#fbfaf6` |

## Usage

All CSS files use CSS custom properties scoped to `[data-theme="dark"]` and `[data-theme="light"]`. To use:

```html
<html data-theme="dark">
  <link rel="stylesheet" href="design-system/foundations/colors_and_type.css">
  <link rel="stylesheet" href="design-system/components/buttons.css">
</html>
```

Toggle themes by setting `data-theme` on `<html>`:
```js
document.documentElement.setAttribute('data-theme', 'light');
```

## Iterative Refinement

Save points are stored in `.save-points/` at the project root. Each save point captures the state of the design system at a milestone, allowing you to iterate without losing progress.

See [`.save-points/README.md`](../../.save-points/README.md) for details.

## Marketing Landing Page

The marketing landing page lives at `../marketing/` and uses the same design tokens:

```
marketing/
├── index.html                   # Full landing page
└── styles.css                   # Marketing styles (extends design system)
```

Sections: Hero, Features, Editor Preview, Testimonials, Pricing, FAQ, CTA, Footer.

## Accessibility

- Respects `prefers-reduced-motion` — all animations disabled when set
- Focus-visible outlines use the accent ring color
- Semantic HTML throughout
- Proper contrast ratios in both themes
